package com.dn_alan.myapplication.rxjava;

public interface ObservableEmitter<T> extends Emitter<T>{



}
