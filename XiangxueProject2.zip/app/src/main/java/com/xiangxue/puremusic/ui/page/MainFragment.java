package com.xiangxue.puremusic.ui.page;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kunminx.player.bean.dto.ChangeMusic;
import com.xiangxue.puremusic.R;
import com.xiangxue.puremusic.bridge.request.MusicRequestViewModel;
import com.xiangxue.puremusic.bridge.state.MainViewModel;
import com.xiangxue.puremusic.data.bean.TestAlbum;
import com.xiangxue.puremusic.databinding.AdapterPlayItemBinding;
import com.xiangxue.puremusic.databinding.FragmentMainBinding;
import com.xiangxue.puremusic.player.PlayerManager;
import com.xiangxue.puremusic.ui.adapter.SimpleBaseBindingAdapter;
import com.xiangxue.puremusic.ui.base.BaseFragment;

// 首页的 Fragment
public class MainFragment extends BaseFragment {

    // 我们操作布局，不去传统方式操作，全部使用Databindxxx
    private FragmentMainBinding mainBinding;
    private MainViewModel mainViewModel; // 首页Fragment的ViewModel
    private MusicRequestViewModel musicRequestViewModel; // 音乐资源相关的VM

    // 适配器
    private SimpleBaseBindingAdapter<TestAlbum.TestMusic, AdapterPlayItemBinding> adapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainViewModel = getActivityViewModelProvider(this).get(MainViewModel.class);
        musicRequestViewModel = getActivityViewModelProvider(this).get(MusicRequestViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, container,false);
        mainBinding = FragmentMainBinding.bind(view);
        mainBinding.setClick(new ClickProxy()); // 设置点击事件，布局就可以直接绑定
        mainBinding.setVm(mainViewModel); // 设置VM，就可以实时数据变化
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 触发  --->  xxxx
        mainViewModel.initTabAndPage.set(true);

        // 触发，---> 还要加载WebView
        mainViewModel.pageAssetPath.set("JetPack之 WorkManager.html");

        // 展示数据，适配器里面的的数据 展示出来
        // 设置设配器(item的布局 和 适配器的绑定)
        adapter = new SimpleBaseBindingAdapter<TestAlbum.TestMusic, AdapterPlayItemBinding>(getContext(), R.layout.adapter_play_item) {
            @Override
            protected void onSimpleBindItem(AdapterPlayItemBinding binding, TestAlbum.TestMusic item, RecyclerView.ViewHolder holder) {
                binding.tvTitle.setText(item.getTitle()); // 标题
                binding.tvArtist.setText(item.getArtist().getName()); // 歌手 就是 艺术家
                Glide.with(binding.ivCover.getContext()).load(item.getCoverImg()).into(binding.ivCover); // 左右边的图片

                // 歌曲下标记录
                int currentIndex = PlayerManager.getInstance().getAlbumIndex(); // 歌曲下标记录

                // 播放的标记
                binding.ivPlayStatus.setColor(currentIndex == holder.getAdapterPosition()
                        ? getResources().getColor(R.color.colorAccent) : Color.TRANSPARENT); // 播放的时候，右变状态图标就是红色， 如果对不上的时候，就是没有

                // 点击Item
                binding.getRoot().setOnClickListener(v -> {
                    Toast.makeText(mContext, "播放音乐", Toast.LENGTH_SHORT).show();
                    PlayerManager.getInstance().playAudio(holder.getAdapterPosition());
                });
            }
        };

        mainBinding.rv.setAdapter(adapter);

        // 播放相关业务的数据（如果这个数据发生了变化，为了更好的体验） 盯着
        PlayerManager.getInstance().getChangeMusicLiveData().observe(getViewLifecycleOwner(), new Observer<ChangeMusic>() {
            @Override
            public void onChanged(ChangeMusic changeMusic) {
                adapter.notifyDataSetChanged(); // 更新及时
            }
        });

        // 音乐资源的 VM
        // 此处理解就是观察者， 有一双眼睛盯着看，getFreeMusicsLiveData变化了，如果变化就执行
        musicRequestViewModel.getFreeMusicsLiveData().observe(getViewLifecycleOwner(), musicAlbum -> {
            if (musicAlbum != null && musicAlbum.getMusics() != null) {
                adapter.setList(musicAlbum.getMusics()); // 数据加入适配器
                adapter.notifyDataSetChanged();

                // 播放相关的业务需要这个数据
                if (PlayerManager.getInstance().getAlbum() == null ||
                        !PlayerManager.getInstance().getAlbum().getAlbumId().equals(musicAlbum.getAlbumId())) {
                    PlayerManager.getInstance().loadAlbum(musicAlbum);
                }
            }
        });

        // 请求数据
        // 保证我们列表没有数据（music list）
        if (PlayerManager.getInstance().getAlbum() == null) {
            musicRequestViewModel.requestFreeMusics();
        }
    }

    public class ClickProxy {

        // 当在首页点击 “菜单” 的时候，直接导航到 ---> 菜单的Fragment界面
        public void openMenu() {
            sharedViewModel.openOrCloseDrawer.setValue(true); // 触发
        }

        // 当在首页点击 “搜索图标” 的时候，直接导航到 ---> 搜索的Fragment界面
        public void search() {
            nav().navigate(R.id.action_mainFragment_to_searchFragment);
        }
    }
}
