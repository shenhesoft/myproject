package com.xiangxue.common.utils;

public final class Cons {

    public static final String TAG = "Derray";

}
