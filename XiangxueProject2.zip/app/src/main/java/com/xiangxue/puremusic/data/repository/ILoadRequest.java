package com.xiangxue.puremusic.data.repository;

/**
 * 为了扩展，这样写（在仓库里面的）
 */
public interface ILoadRequest {
}
