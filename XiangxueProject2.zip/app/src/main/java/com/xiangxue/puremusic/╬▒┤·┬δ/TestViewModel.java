package com.xiangxue.puremusic.伪代码;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.xiangxue.puremusic.伪代码.仓库.DataRepo;

public class TestViewModel extends ViewModel {

    private MutableLiveData loginData = new MutableLiveData();

    public MutableLiveData getLoginData() {
        return loginData;
    }

    public void requestLogin(String name, String pwd) {
        DataRepo.getInstance().requestLogin(getLoginData(), name, pwd);
    }

}
