package com.android.as_kt1

// KT 方法名(输入类型) : 输出类型【声明部分】      【实现部分】{}
// KT 先有输入  后有输出

// Kotlin的方法
fun main()/* : Unit   */ {
    val age : Int = 19 // Int类型  String类型  Double类型    // 函数类型是 (输入类型) -> 输出类型

    // 面试题：   () -> Unit      输入没有 -> 输出没有
    val method01 : () -> Unit = { println("method01 run")  }
    method01()

    // 面试题：   (String) -> Boolean
    val method02 : (String) -> Boolean = {str: String ->
        true // Boolean
    }
    println(method02("Derry"))

    // 面试题：  (String) -> Int
    val method04 : (String) -> Int = { str: String ->
        str.length // Int
    }

    // 面试题： (Int,Int) -> Int
    val method05 = {n1: Int, n2: Int ->
        n1 / n2 // Int
    }

    // 面试题： (Any) -> Any     Any == Object
    val method06 = {any: Any ->
        any // Any
    }
    println(method06(5465))
    println(method06("Derry"))
    println(method06(true))

    // 面试题： (Char)-> Unit
    val method07  = { sex: Char -> Unit
        println(if(sex == '男') "先生你好" else if(sex == '女') "女士你好" else "人妖")	 // Unit
    }
    method07('男')
    method07('女')
    method07('A')

    // 面试题： (Int, Int, Int) -> Int
    val method08 : (Int, Int, Int) -> Int = {n1: Int, n2:Int, n3:Int ->
        n1 + n2 + n3
    }

    // 面试题：(Int, String, Float) -> String
    val method09 = {n1: Int, n2:String, n3:Float ->
        "你的姓名:$n2,你的年龄:$n1,你的体重:$n3" // String
    }

    // 面试题：(List<String>) -> Unit
    val method10 = { str: List<String> ->
        for(i in str) {
            println("你的每一条是:$i") // Unit
        }
    }

    // 面试题：(() -> Unit) ->  Unit
    val method11 = { a1: () -> Unit ->
        a1() // 调用a1函数   调用a1会返回 a1 的 Unit
    }
    /*method11(
        {
            println("我是a1函数的实现，我被调用了")
        }
    )*/
    method11 {
        println("我是a1函数的实现，我被调用了")
    }

    // 面试题：(String, String) -> Unit
    val method12 = { userName: String, userPwd: String ->

    }

    // 面试题：(String, String, (Boolean) -> Unit) -> Unit
    val method13 = { userName: String, userPwd: String, a : (Boolean) -> Unit ->
        if(userName == "Derry" && userPwd == "123456") {
            a(true)	 // 登录成功 调用 a 方法传入 true
        } else {
            a(false)  // 登录失败 调用 a 方法传入 false
        }
    }
    /*method13("Derry2", "123456",
        // a函数的实现
        { it: Boolean ->
            if (it) println("恭喜你，登录成功") else println("不恭喜，登录失败")
        }
    )*/
    method13("Derry2", "123456") {
        if (it) println("恭喜你，登录成功") else println("不恭喜，登录失败")
    }

    // 精讲版本，取出所有业务逻辑
    // 面试题：(() -> Unit) -> Unit
    val method14 = { a : () -> Unit ->
        a()	 // 调用 a函数
    }
    method14 {
      println("a函数 实现被执行了")
    }

    // 面试题： 考点 method15函数 再返回一个函数
    // (String) ->  (Int) -> String
    val method15 = { str: String ->
        // 函数   输入 输出    (Int) -> String
        { n1: Int ->
            "n1:$n1 我是String类型的字符串" // String
        }
    }
    // 为什么是两个括号  第一个括号 调用method15函数而已
    //                第二个括号 调用method15函数 返回的函数
    println(method15("Derry")(999))
}