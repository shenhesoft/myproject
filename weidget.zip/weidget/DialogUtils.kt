package com.example.mediaevalutionsystem.weidget

import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import com.example.mediaevalutionsystem.weidget.interceptor.DialogInterceptor

object DialogUtils {
    @JvmStatic
    fun showAlertDialog(context: Context, title: String, content: String): AlertDialog? {
        if (context ==null) return null
        val builder = AlertDialog.Builder(context)
        builder.setTitle(title).setMessage(content)
//        builder.setNegativeButton(""){}

        return builder.show()

    }

    @JvmStatic
    fun getChainOfDialog(context: Context):DialogInterceptor{
        val loginDialogInterface = LoginDialog(context)
        val registerDialogInterface = RegisterDialog(context)
        registerDialogInterface.setNextInterceptor(loginDialogInterface)
        return registerDialogInterface
    }
}