package com.xiangxue.common.images;

/**
 * 图片加载管理器
 */
public class GlideManager {

    // .....

}
