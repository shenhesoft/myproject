package com.example.mediaevalutionsystem.weidget;

import java.util.List;

public class Chain {
    private List<Interceptor> interceptors;
    private int index;
    private String content;

    public Chain(List<Interceptor> interceptors, int index) {
        this.interceptors = interceptors;
        this.index = index;
    }

    public Chain(List<Interceptor> interceptors, int index, String content) {
        this.interceptors = interceptors;
        this.index = index;
        this.content = content;
    }

    public boolean Processed(){
        if (index>=interceptors.size()){
            return true;
        }
        Chain chain = new Chain(interceptors,index+1);
        Interceptor interceptor = interceptors.get(index);
        return interceptor.intercept(chain);
    }
}
