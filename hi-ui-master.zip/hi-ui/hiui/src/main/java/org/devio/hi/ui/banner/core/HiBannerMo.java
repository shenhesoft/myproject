package org.devio.hi.ui.banner.core;

/**
 * HiBanner的实体类，继承该实体类来实现自己的Mo
 */
public abstract class HiBannerMo {
    public String url;
}
