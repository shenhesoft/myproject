package com.xiangxue.news.homefragment.base;

public interface BaseCustomView<D extends BaseCustomViewModel> {
    void setData(D data);
}
