package com.xiangxue.puremusic.伪代码.仓库;

import androidx.lifecycle.MutableLiveData;

public class DataRepo {

    static DataRepo instance;

    public static DataRepo getInstance() {
        if (instance == null) {

        }
        return instance;
    }

    public void requestLogin(MutableLiveData loginData, String name, String pwd) {
        new Thread(){
            @Override
            public void run() {
                super.run();

                if (name.equals("derry") && pwd.equals("123")) {
                    loginData.setValue("登录成功");
                } else {
                    loginData.setValue("登录失败");
                }
            }
        }.start();
    }

}
