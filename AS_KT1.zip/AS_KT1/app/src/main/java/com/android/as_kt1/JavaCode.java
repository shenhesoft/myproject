package com.android.as_kt1;

public class JavaCode {

    public static void main(String[] afasfsfasfsfsafasfsafasfsasf) {

    }

    // Java的主方法的规范是    public static 无返回输出类型的 main(输入必须是String数组)

    // public 输出类型 方法名(输入类型) {}

    // Java 输出类型 方法名(输入类型)【声明部分】      【实现部分】{}

    // 面试： 输出没有  输入没有             输出 void    输入 ()             输出 -> 输入
    static void method01() { System.out.println("method01 run"); }
}
