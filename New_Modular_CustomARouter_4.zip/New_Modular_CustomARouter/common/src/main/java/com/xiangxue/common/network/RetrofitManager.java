package com.xiangxue.common.network;

/**
 * 网络请求管理器
 */
public class RetrofitManager {

    // .....

}
