package com.example.mediaevalutionsystem.weidget

interface Interceptor {
    fun intercept(chain:Chain):Boolean?
}