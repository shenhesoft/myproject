package com.enjoy.skin.lib;

/**
 * @author 享学课堂 jett
 */

public interface SkinViewSupport {

    void applySkin();
}
