package com.xiangxue.news.homefragment.newslist

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.xiangxue.network.TecentNetworkWithoutEnvelopeApi
import com.xiangxue.network.apiresponse.NetworkResponse
import com.xiangxue.news.homefragment.api.NewsApiInterface
import com.xiangxue.news.homefragment.newslist.commoncomposables.LoadMoreListHandler
import com.xiangxue.news.homefragment.newslist.composables.title.TitleSection
import com.xiangxue.news.homefragment.newslist.composables.title.TitleComposableModel
import com.xiangxue.news.homefragment.newslist.composables.titlepicture.TitlePictureSection
import com.xiangxue.news.homefragment.newslist.composables.titlepicture.TitlePictureComposableModel
import kotlinx.coroutines.launch
import androidx.compose.foundation.lazy.items

/**
 * Created by Allen on 2017/7/20.
 * 保留所有版权，未经允许请不要分享到互联网和其他人
 */
class NewsListFragment : Fragment() {
    private var mPage = 1
    private val contentlist = mutableStateListOf<Any>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        load()
        return ComposeView(requireContext()).apply {
            setContent {
                val listState = rememberLazyListState()
                LazyColumn(
                    contentPadding = PaddingValues(
                        start = 16.dp,
                        end = 16.dp,
                        bottom = 10.dp,
                        top = 10.dp
                    ),
                    state = listState
                ) {
                    items(contentlist) {
                        if(it is TitleComposableModel){
                            TitleSection(it)
                        } else if(it is TitlePictureComposableModel){
                            TitlePictureSection(it)
                        }
                    }
                }

                LoadMoreListHandler(listState = listState) {
                    load()
                }
            }
        }
    }

    private fun load() {
        lifecycleScope.launch {

            val newsListBean =
                TecentNetworkWithoutEnvelopeApi.getService(NewsApiInterface::class.java)
                    .getNewsList(
                        arguments?.getString(BUNDLE_KEY_PARAM_CHANNEL_ID),
                        arguments?.getString(BUNDLE_KEY_PARAM_CHANNEL_NAME), mPage.toString()
                    )
            when(newsListBean) {
                is NetworkResponse.Success -> {
                    if (mPage == 1) {
                        contentlist.clear()
                    }
                    for (source in (newsListBean.body)!!.pagebean!!.contentlist!!) {
                        if (source.imageurls != null && source.imageurls.size > 1) {
                            val viewModel =
                                TitlePictureComposableModel(source.title ?: "", source.imageurls[0].url ?: "")
                            contentlist.add(viewModel)
                        } else {
                            val viewModel = TitleComposableModel(source.title ?: "")
                            contentlist.add(viewModel)
                        }
                    }

                    mPage++
                }
                else -> {

                }
            }
        }
    }

    companion object {
        const val BUNDLE_KEY_PARAM_CHANNEL_ID = "bundle_key_param_channel_id"
        const val BUNDLE_KEY_PARAM_CHANNEL_NAME = "bundle_key_param_channel_name"
        fun newInstance(channelId: String?, channelName: String?): NewsListFragment {
            val fragment = NewsListFragment()
            val bundle = Bundle()
            bundle.putString(BUNDLE_KEY_PARAM_CHANNEL_ID, channelId)
            bundle.putString(BUNDLE_KEY_PARAM_CHANNEL_NAME, channelName)
            fragment.arguments = bundle
            return fragment
        }
    }
}