package com.xiangxue.new_modular_customarouter;

import com.xiangxue.arouter_annotation.ARouter;

// @ARouter(path = "/app/Derry")
// @ARouter注解目前仅限用于Activity类之上
/*
public class Derry {
}
*/
