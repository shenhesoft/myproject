//package com.google.samples.apps.sunflower.bindings;
//
//import android.view.View;
//
//public class XXXAdapter {
//
//    // 显示 隐藏 功能
//    // TextView 的显示和因此   靠此isGone
//    @androidx.databinding.BindingAdapter("xxxx")
//    public static void bindISGone(View view, boolean isOK) {
//        view.setVisibility(isOK ? View.GONE : View.VISIBLE);
//    }
//
//}
