package com.android.as_kt1

fun main() {
    // TODO 变量： 使用“val”或者是“var”关键字作为开头，后面跟“变量名称”，接着是“变量类型”和“赋值语句”

    // 变量：在Java中，如果我们要声明变量，我们必须要声明它的类型，后面跟着变量的名称和对应的值，然后以分号结尾。
    // Integer age = 30;

    /*
   关键字    变量类型
    ↓         ↓           */
    var age : Int = 30      /*
         ↑           ↑
        变量名      变量值    */

    // TODO 分号：在Kotlin中，不需要分号，若要隔开，换行隔开，或，;隔开
    var age1 : Int = 100 ; var age2 : Int = 100
    var age3 : Int = 100
    var age4 : Int = 100

    // var a1, a2,a3 : Int = 100

    // TODO 类型推导：在Kotlin中，变量类型可以省略不写，会通过值推导出类型
    var age5 = 100 // 背后隐式代码 var age5 : Int = 100 --- 默认推导类型为： Int

    // TODO 多用val：val是只读，var是可读可改，只要是不再修改，都用val
    var age6 = 100
    age6 = 101 // var可改
    println(age6) // var可读

    val age7 = 100
    // age7 = 101 // val不可改，编译器报错
    println(age7) // val只读

    // TODO 基础类型
    // 基础类型：在Java中，有两种类型，整型int和Integer，前者是原始类型（基本类型），后者是包装类型（引用对象）。
    /*
    int i = 0; // 原始类型
    Integer j = 1; // 包装类型
    */

    // 在Kotlin中，没有原始类型这个概念，Kotlin一切都是对象
    // Double   kotlin class
    // Float    kotlin class
    // Long     kotlin class
    // Int      kotlin class
    // Short    kotlin class
    // Char     kotlin class
    // Boolean  kotlin class

    // TODO Kotlin基础类型的良苦用心：
    // Java的基础类型并不是完全面向对象，因为它存在原始类型，而原始类型并不属于对象。
    // 而Kotlin则不一样，它从语言设计的层面上就规避了这个问题，基础类型则是完全面向对象的。
    val d1 : Double = 100.toDouble().toLong().toDouble()

    // TODO 空安全：由于 基础类型则是完全面向对象的，那么对象就有可能为空，那么空安全机制就应运而生了
    // val d2 : Double = null // 非可空类型，不能赋值为null，编译不通过
    val d3 : Double? = null // 可空类型，能赋值为null，编译通过

    // 可空类型(可能编译后 包装类型)  >  非可空类型 (编译后 一直都是基本类型)
    //  包装类型    =    基本类型   先这样理解
    // 为空类型：  1.可以存null值。 2.可以存正常值。
    // 非可空类型：1.只能存正常值。 不能给null值，编译不通过
    var d4 : Double = 6588776.7
    var d5 : Double ? = null
    // d4 = d5 // 编译不通过，非可空类型 不能 接收 可空类型    小 = 大
    // d5 = d4 // 编译通过，可空类型 可以 接收 非可空类型  大 = 小

    // d4 = d5 // 编译不通过 的 解决方案（靠Kotlin编译期的监测）
    if (d5 != null) d4 = d5

    // TODO Java隐式转换 VS Kotlin显示转换
    /*
       int intValue = 9999;       短 小
       long longValue = intValue; 长 大

       longValue = intValue  1   有问题2（切点，自动转，你看不到，隐式的，有隐患，没有把这个转的过程暴露出来）
       */

    // Kotlin推荐显示转换（好处：1.开发者自己转换 2.可读性特别强 3.一切都是透明的）
    val intValue = 666
    val longValue : Long = intValue.toLong() // intValue.toLong这个是开发者写的，是开发者的责任

    // TODO Boolean类型
    val isOk = true
    val isNotOk = false
    println(isOk)
    println(isNotOk)

    // TODO Char类型
    val c = 'A'
    // val code : Int = c // 编译器报错
    val code : Int = c.toInt() // 必须透明化，可读性强，一切都需要暴露出来
    println(code) // 65

    // TODO String字符串摸版
    val name = "Derry"
    print("你的名字是:$name!")

    val array = arrayOf("Java", "Kotlin")
    print("你在学习什么${array[1]}语言呀!")

    val info = """
              仍是雨夜
              凝望窗外
              沉默的天际
              问苍天
              可会知
              心里的感觉
              """
    println(info)

    val info2 = """
              仍是雨夜
              凝望窗外
              沉默的天际
              问苍天
              可会知
              心里的感觉
              """.trimIndent()
    println(info2) // 去除缩进

    // TODO 数组 Ctrl + Shift + P  序列化了
    val arrayInt = arrayOf(100000, 200000, 300000) // 类型会被推导为整型数组 Array<Int>
    val arrayString = arrayOf("张三", "李四", "王五") // 类型会被推导为字符串数组 Array<String>
    // Java length  size

    // 在Java中，“array.length”，“list.size”， 而在Kotlin中，这个问题统一采用size (array.size  list.size)
    arrayOf(100000, 200000, 300000).size
    listOf(100000, 200000, 300000).size

    // TODO 函数调用
    derryFunction("Derry")
    derryFunction2(name = "Derry") // 命名参数：明确可见的参数名，可读性更强

    // 命名参数
    fun createStudent( name: String, age: Int, gender: Int, friendCount: Int, feedCount: Int, likeCount: Long, commentCount: Int) {}
    createStudent("Zhangsan", 30, 1, 78, 2093, 10937, 3285) // 可读性差,Java的做法（建造者设计模式）
    createStudent( name = "Zhangsan", age = 30, gender = 1, friendCount = 78, feedCount = 2093, likeCount = 10937, commentCount = 3285) // 可读性强，易维护
    createStudent( feedCount = 2093, likeCount = 10937, commentCount = 3285, name = "Zhangsan", age = 30, gender = 1, friendCount = 78) // 顺序灵活，难写错

    // 默认参数（例如：一个函数一百个参数，用户使用不想传那么多参数，怎么办？ Java采用建造者设计模式解决， Kotlin可以直接用 默认参数解决）
    fun createTeacher(name: String, age: Int, gender: Int = 1, friendCount: Int = 0, feedCount: Int = 0, likeCount: Long = 0L, commentCount: Int = 0) {}
    createTeacher( name = "李元霸", age = 30, commentCount = 3285) // 其他的参数不想传递，就启动默认参数

    // TODO 流程控制
    // if表达式（Java的if是语句 ，   Kotlin的if是表达式 可以返回 灵活多变 并且有语句的功能）
    val isSuccessful = true
    val responseResult = if (isSuccessful) "恭喜你，登录成功" else "不恭喜，你登录失败了!"
    println(responseResult)

    // Elvis表达式 ?: 在函数中妙用
    fun getNameLength(name: String) : Int {
        return if (name != null) name.length else -1
    }
    fun getNameLength2(name: String?) : Int{
        return name ?.length ?: -1   // name等于null，就会返回-1，    name有值 就会返回值长度
        // xxx ?:  如果xxx是null 就会执行 ?: 后面的区域代码
    }
    println(getNameLength2("Derry"))

    // when表达式 （Java都是语句 ，   Kotlin的if when 等等 是表达式 可以返回 灵活多变 并且有语句的功能）
    val number = 1
    val message : String = when(number) {
        1 -> "number等于一"
        2 -> "number等于二"
        else -> "number 不是一也不是二" // 如果去掉这行，会报错
    }
    print(message)

    // for循环特点
    val numberArray = arrayOf(100, 200, 300, 400, 500, 600)
    for (i in numberArray) {
        println(i)
    }

    println()

    for (i in 100..600) { // 包含了 100 到 600
        println(i)
    }

    println()

    for (i in 600 downTo 100 step 2) { // 600 到 100
        println(i)
    }
}


// TODO 函数声明
// Kotlin的函数 更加符合人类正常思维， 先有输入，再有输出
/*
关键字    函数名          参数类型   返回值类型
 ↓        ↓                ↓       ↓      */
fun derryFunction(name: String): String {
    return "你的姓名是:$name!"
}/*   ↑
   花括号内为：函数体
*/

// TODO 单一表达式函数
fun derryFunction2(name: String) : String = "你的姓名是:$name!"
fun derryFunction3(name: String) = "你的姓名是:$name!" // 通过返回值类型推导出，返回类型String