package com.xiangxue.common.utils;

/**
 * 常用工具类
 */
public final class CommonUtils {
}
