package com.xiangxue.news.homefragment.newslist.views.picturetitleview;

import com.xiangxue.news.homefragment.base.BaseCustomViewModel;

public class PictureTitleViewModel extends BaseCustomViewModel {
    public String pictureUrl;
}
