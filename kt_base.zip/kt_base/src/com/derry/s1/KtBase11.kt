package com.derry.s1

const val PI1 = 3.1415
const val PI2 = 3.1415
const val age = 99

// TODO 11.学习查看Kotlin反编译后字节码
fun main() {
    val name = "Derry"
    val number = 108
    val number2 = 200
    val isOk = false

    val s = 'A'
}