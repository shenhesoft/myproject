package com.xiangxue.rxjavademo.source;

public interface Flag {
    String TAG = "SourceActivity";
}
