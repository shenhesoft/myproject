package com.xiangxue.news.homefragment.headlinenews

import android.os.Parcelable
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.xiangxue.news.homefragment.api.Channel
import com.xiangxue.news.homefragment.newslist.NewsListFragment

/**
 * Created by Allen on 2017/7/20.
 * 保留所有版权，未经允许请不要分享到互联网和其他人
 */
class HeadlineNewsFragmentAdapter(fm: FragmentManager?) : FragmentPagerAdapter(
    fm!!
) {
    private var mChannels: List<Channel>? = null
    fun setChannels(channels: List<Channel>?) {
        mChannels = channels
        notifyDataSetChanged()
    }

    override fun getItem(pos: Int): Fragment {
        return NewsListFragment.newInstance(
            mChannels!![pos].channelId,
            mChannels!![pos].name
        )
    }

    override fun getCount(): Int {
        return if (mChannels != null && mChannels!!.size > 0) {
            mChannels!!.size
        } else 0
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return mChannels!![position].name
    }

    override fun restoreState(parcelable: Parcelable?, classLoader: ClassLoader?) {}
}