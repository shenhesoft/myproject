package com.xiangxue.news.homefragment.newslist.views.titleview;

import com.xiangxue.news.homefragment.base.BaseCustomViewModel;

public class TitleViewModel extends BaseCustomViewModel {
}
