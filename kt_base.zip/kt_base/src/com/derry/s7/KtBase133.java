package com.derry.s7;

public class KtBase133 {

    public static void main(String[] args) {
        // Java端
        // KtBase133Kt.show("张三") // Java无法享用 KT的默认参数

        KtBase133Kt.toast("张三"); // 相当于 Java 享用 KT的默认参数
    }
}
