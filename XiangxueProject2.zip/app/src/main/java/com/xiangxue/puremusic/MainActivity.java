package com.xiangxue.puremusic;

import android.os.Bundle;

import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Observer;

import com.xiangxue.puremusic.databinding.ActivityMainBinding;
import com.xiangxue.puremusic.bridge.state.MainActivityViewModel;
import com.xiangxue.puremusic.ui.base.BaseActivity;

// 主页  管理者
public class MainActivity extends BaseActivity {

    ActivityMainBinding mainBinding;
    MainActivityViewModel mainActivityViewModel;
    private boolean isListened = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivityViewModel = getActivityViewModelProvider(this).get(MainActivityViewModel.class);
        mainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        mainBinding.setLifecycleOwner(this);
        mainBinding.setVm(mainActivityViewModel);

        // mainActivityViewModel 的 变化 先暂停  (抽屉控件干了，我就不需要干了)
       /* mainActivityViewModel.allowDrawerOpen.observe(this, new Observer<Boolean>() {
            @Override
            public void onChanged(Boolean aBoolean) {
                // 需求
            }
        });*/

       // 共享

       mSharedViewModel.activityCanBeClosedDirectly.observe(this, new Observer<Boolean>() {
           @Override
           public void onChanged(Boolean aBoolean) {
               // 先不写，作用不大
           }
       });

       // 间接的可以打开菜单
       mSharedViewModel.openOrCloseDrawer.observe(this, new Observer<Boolean>() {
           @Override
           public void onChanged(Boolean aBoolean) {
               mainActivityViewModel.openDrawer.setValue(aBoolean); // 触发，就会改变，---> 观察（打开菜单逻辑）
           }
       });

       // 间接的xxxx
       mSharedViewModel.enableSwipeDrawer.observe(this, new Observer<Boolean>() {
           @Override
           public void onChanged(Boolean aBoolean) {
               mainActivityViewModel.allowDrawerOpen.setValue(aBoolean); // 触发抽屉控件关联的值
           }
       });
    }

    /**
     * 详情看：https://www.cnblogs.com/lijunamneg/archive/2013/01/19/2867532.html
     * 这个onWindowFocusChanged指的是这个Activity得到或者失去焦点的时候 就会call。。
     * 也就是说 如果你想要做一个Activity一加载完毕，就触发什么的话 完全可以用这个！！！
     *  entry: onStart---->onResume---->onAttachedToWindow----------->onWindowVisibilityChanged--visibility=0---------->onWindowFocusChanged(true)------->
     * @param hasFocus
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (!isListened) {
            mSharedViewModel.timeToAddSlideListener.setValue(true); // 触发改变
            isListened = true;
        }
    }

    /**
     * https://www.jianshu.com/p/d54cd7a724bc
     * Android中在按下back键时会调用到onBackPressed()方法，
     * onBackPressed相对于finish方法，还做了一些其他操作，
     * 而这些操作涉及到Activity的状态，所以调用还是需要谨慎对待。
     */
    @Override
    public void onBackPressed() {
        // super.onBackPressed();

        mSharedViewModel.closeSlidePanelIfExpanded.setValue(true); // 触发改变
    }
}
