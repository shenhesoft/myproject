package com.xiangxue.news.homefragment.base;

public class BaseCustomViewModel {
    public String jumpUri;
    public String title;
}
