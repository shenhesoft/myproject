


同学们好，欢迎来到享学课堂，我是今天的主讲 Leo老师，

我们正式 上课的时间 20：05，已经进来的同学请耐心等候下其他同学。



宿主  --  数组

插件化 优于 组件化 

热修复  

ABTest --- 

多开

换肤

成本高 --- 一线企业 玩的起

插件  类的方法 以及 资源

反射

Class  --- 一切皆对象

Car 类  

Person  --- Class 类

Class Person{
	private static int age; // Field 类
}

Person.age  = 19;

Field  ageField = Class.getField("age"); // new Person().age  
int leo =  age
ageField.get(null); -- ageField.get(new Person);
ageField.set();

1. 产生大量的临时对象
2. 检查可见性 
3. 会生成字节码 --- 没有优化
4. 类型转换

java  Android   类加载机制  

类加载器  --- 加载类 的

PathClassLoader --》 parent（ClassLoader类型的对象），BootClassLoader 没有parent

PathClassLoader  --- 应用的 类 -- 第三方库  
BootClassLoader  --- SDK的类

Parent -- 父母 双亲  

查找  Hook  反射 启动插件的类

dexFile --- dex 文件

Element -- dexFile  --- apk  多个dex文件

Element[] dexElements -- 一个app的所有 class 文件都在 dexElements 里面

因为 宿主的MainActivity  在  宿主 的  dexElements 里面

宿主dexElements = 宿主dexElements + 插件dexElements

1.获取宿主dexElements
2.获取插件dexElements
3.合并两个dexElements
4.将新的dexElements 赋值到 宿主dexElements

目标：dexElements  -- DexPathList类的对象 -- BaseDexClassLoader的对象，类加载器

获取的是宿主的类加载器  --- 反射 dexElements  宿主 

获取的是插件的类加载器  --- 反射 dexElements  插件


new DexPathList().dexElements = 123;

DexPathList.dexElements = 123;





































