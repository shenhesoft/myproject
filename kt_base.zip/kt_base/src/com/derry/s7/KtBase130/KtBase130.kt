package com.derry.s7.KtBase130

// TODO 130.Kotlin语言的单例模式
// 1.饿汉式的实现  Java版本   ----  KT版本
// 2.懒汉式的实现  Java版本   ----  KT版本
// 3.懒汉式的实现 安全  Java版本  ----  KT版本
// 4.懒汉式的实现 双重校验安全  Java版本  ----  KT版本