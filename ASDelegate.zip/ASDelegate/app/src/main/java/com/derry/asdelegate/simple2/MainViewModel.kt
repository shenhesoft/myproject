package com.derry.asdelegate.simple2

import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {

    var value = "MyName"

}