package com.derry.s7;

public class KtBase131 {

    public static void main(String[] args) {
        // KtBase131Kt.getStudentNameValueInfo("Derry is OK");

        Stu.getStudentNameValueInfo("Derry is OK a");
    }
}
