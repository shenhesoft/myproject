package com.xiangxue.base.customview;

public interface IBaseCustomView<D extends BaseCustomViewModel> {
    void setData(D data);
}
