package com.example.mediaevalutionsystem.weidget.interceptor;


public abstract class DialogInterceptor {
    public static String SHOW_REGISTER_DIALOG = "1";
    public static String SHOW_LOGIN_DIALOG = "2";
    public static String SHOW_COMMON_DIALOG = "3";
    private DialogInterceptor mNextInterceptor;
    protected String tag;


    public void setNextInterceptor(DialogInterceptor nextInterceptor) {
        this.mNextInterceptor = mNextInterceptor;
    }

    public void showDialog(String tag,String message,boolean isShow){
        if (tag.equals(SHOW_LOGIN_DIALOG)){

        }
        if (isShow){
         log(tag,message);
            return;
        }
        if (mNextInterceptor!=null){
            mNextInterceptor.showDialog(tag,message,isShow);
        }
    }

    protected abstract void showRegisterDialog(String tag,String message);

}
