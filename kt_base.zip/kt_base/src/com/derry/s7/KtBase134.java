package com.derry.s7;

public class KtBase134 {

    public static void main(String[] args) {
        // Java 端
        System.out.println(MyObject.TARGET);

        MyObject.showAction("Kevin");
    }
}
