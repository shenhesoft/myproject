package com.derry.s6;

// in T  out T 声明处指定关系  声明处泛型  这个是Java没有的功能
public class KtBase111</*? extends */T> {
}
