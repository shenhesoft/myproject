package com.derry.s1

// TODO 09.Kotlin语言的类型推断
fun main() {
    // 提示：Explicitly given type is redundant here
    //      显示给定的类型在这里是多余的
    val info : String = "Derry is Success"
    println(info)

    val age = 98
    println(age)

    val xxx = 'A'
}