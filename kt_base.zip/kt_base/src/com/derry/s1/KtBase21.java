package com.derry.s1;

public class KtBase21 {

    // in  is  在java里面就是普通函数

    public  static final void in() {
        System.out.println("in run success");
    }

    public  static final void is() {
        System.out.println("is run success");
    }
}
