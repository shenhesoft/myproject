package com.xiangxue.arch_demo;

public interface IMainActivity {
    void removeMeAndGoNextFragment();
}
