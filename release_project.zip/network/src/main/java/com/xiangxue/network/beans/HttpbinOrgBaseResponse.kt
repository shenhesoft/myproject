package com.xiangxue.network.beans

class HttpbinOrgBaseResponse {
}