package com.derry.s6;

public class KtBase129 {

    public String getInfo1() {
        return "Derry Info1";
    }

    public String getInfo2() {
        return null;
    }
}
