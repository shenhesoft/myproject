package com.xiangxue.new_modular_customarouter;

import com.xiangxue.arouter_annotation.Parameter;

public class Derry2 {

 /*   @Parameter
    String name;

    @Parameter
    String sex;

    @Parameter
    int age;
*/
}
