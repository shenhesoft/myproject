package k03

fun main() {
    // 模拟AndroidManifest.xml的解析

    /*manifest {
        pkg("")

        permission()

        // 四大组件
        application {

            activity {

            }

        }
    }*/
}