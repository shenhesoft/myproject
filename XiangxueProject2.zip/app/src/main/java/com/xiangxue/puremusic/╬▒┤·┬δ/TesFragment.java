package com.xiangxue.puremusic.伪代码;

import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

public class TesFragment extends Fragment {

    TestViewModel testViewModel = ViewModelProviders.of(this).get(TestViewModel.class);

    // 请求数据
    public void request() {
        testViewModel.requestLogin("derry", "123");
    }

    // 更新ＵＩ
    TextView textView;

    public void onCreateView() {
        testViewModel.getLoginData().observe(getViewLifecycleOwner(), new Observer() {
            @Override
            public void onChanged(Object o) {
                textView.setText(o.toString());
            }
        });
    }
}
