package com.xiangxue.network.rxbus;


public enum ThreadMode {
    SINGLE, COMPUTATION, IO, TRAMPOLINE, NEW_THREAD, MAIN
}
