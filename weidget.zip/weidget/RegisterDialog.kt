package com.example.mediaevalutionsystem.weidget

import android.app.AlertDialog
import android.content.Context
import android.util.Log
import com.example.mediaevalutionsystem.weidget.interceptor.DialogInterceptor


class RegisterDialog constructor(context: Context) :DialogInterceptor(){
    private var alertDialog: AlertDialog? = null
    private var mContext:Context? = null
    enum class Type{
        SUCCESS,FAILED,LOAD;
    }

    init {
        this.mContext = context
    }

    fun showDialog(type: Type): AlertDialog? {
        alertDialog = when (type) {
            Type.SUCCESS -> showSuccessDialog()
            Type.FAILED -> showFailedDialog()
            Type.LOAD -> showLoadDialog()
        }
        return alertDialog
    }

    private fun showLoadDialog():AlertDialog? {
        alertDialog = DialogUtils.showAlertDialog(mContext!!,"register loading","register loading-----")
        if (alertDialog!=null){
            isShow = true}
        return alertDialog
    }

    private fun showFailedDialog() :AlertDialog? {
        alertDialog = DialogUtils.showAlertDialog(mContext!!,"register failed","register failed-----")
        if (alertDialog!=null){
            isShow = true}
        return alertDialog
    }

    private fun showSuccessDialog() :AlertDialog? {
        alertDialog = DialogUtils.showAlertDialog(mContext!!,"register success","register success-----")
        if (alertDialog!=null){
            isShow = true}
        return alertDialog
    }

    override fun log(tag: String?, message: String?) {
        if (tag!=null&&message!=null){
            Log.i(tag, message)}
    }

}