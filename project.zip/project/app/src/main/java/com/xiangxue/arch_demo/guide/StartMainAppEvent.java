package com.xiangxue.arch_demo.guide;

public class StartMainAppEvent {
}
