package com.dn_alan.myapplication.rxjava;

public interface Disposeble<R> {

    void disposa(boolean bool);

    boolean isDisposad();
}
