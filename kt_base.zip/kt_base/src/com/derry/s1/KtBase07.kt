package com.derry.s1

// TODO 07.Kotlin语言声明变量与内置数据类型
fun main() {

    println("Hello World")

    // TODO ================== 声明变量

    /*
       可读可改  变量名    类型      值
       var      name  : String = "Derry"
     */
    var name : String = "Derry"
    // name = "Lance"
    println(name)

    // TODO ================= 内置数据类型
    /*
        String      字符串
        Char        单字符
        Boolean     true/false
        Int         整形
        Double      小数
        List        集合
        Set         无重复的元素集合
        Map         键值对的集合

        Int   ---> java int
        Float  ---> java float
     */


}