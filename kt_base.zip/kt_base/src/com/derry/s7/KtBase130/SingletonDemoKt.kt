package com.derry.s7.KtBase130

// 1.饿汉式的实现  KT版本
object SingletonDemoKt