package com.xiangxue.news.homefragment.newslist.composables.title

data class TitleComposableModel(
    var title: String
)
