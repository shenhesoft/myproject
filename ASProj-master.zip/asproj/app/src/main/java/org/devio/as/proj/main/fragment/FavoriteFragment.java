package org.devio.as.proj.main.fragment;

import org.devio.as.proj.common.ui.component.HiBaseFragment;
import org.devio.as.proj.main.R;

public class FavoriteFragment extends HiBaseFragment {
    @Override
    public int getLayoutId() {
        return R.layout.fragment_favoite;
    }
}
