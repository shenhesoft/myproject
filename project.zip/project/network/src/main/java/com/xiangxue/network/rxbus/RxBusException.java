package com.xiangxue.network.rxbus;


public class RxBusException extends RuntimeException {
    public RxBusException(String detailMessage) {
        super(detailMessage);
    }
}
