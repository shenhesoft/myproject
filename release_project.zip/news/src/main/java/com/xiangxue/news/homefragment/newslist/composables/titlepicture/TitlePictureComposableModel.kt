package com.xiangxue.news.homefragment.newslist.composables.titlepicture

data class TitlePictureComposableModel(
    var title: String,
    var picture: String,
)
