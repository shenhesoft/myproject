package com.xiangxue.puremusic;

public class TestViewModel {
}
