package com.google.samples.apps.sunflower.utilites;

/**
 * 整个项目所用到的常量 类
 */
public interface Constants {
    String DATABASE_NAME = "sunflower-db";  // 数据库的名称
    String PLANT_DATA_FILENAME = "plants.json"; // json数据文件的名称
}
