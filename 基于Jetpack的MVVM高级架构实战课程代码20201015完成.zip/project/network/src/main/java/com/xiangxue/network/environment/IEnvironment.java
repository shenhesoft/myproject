package com.xiangxue.network.environment;

public interface IEnvironment {
    String getFormal();

    String getTest();
}
